package com.burgundy.walletdemo;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list; TextView balance; double amount=0;
    final int burgundy=Color.rgb(122,31,61);
    NumberFormat nf=NumberFormat.getCurrencyInstance(new Locale("en","NG"));

    public void onCreate(Bundle b){super.onCreate(b); build();}
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setPadding(22,18,22,18); return t; }
    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,20,20,10);
        TextView head=tv("Burgundy Wallet",26); head.setTextColor(burgundy); head.setTypeface(null,1); root.addView(head);
        TextView demo=tv("VIRTUAL DEMO • NO REAL MONEY",12); demo.setTextColor(Color.DKGRAY); root.addView(demo);
        balance=tv("₦0.00",36); balance.setTextColor(Color.BLACK); balance.setPadding(22,35,22,35); root.addView(balance);
        LinearLayout row=new LinearLayout(this);
        Button top=new Button(this); top.setText("＋ TOP UP"); top.setOnClickListener(v->topUp());
        Button send=new Button(this); send.setText("SEND MONEY"); send.setOnClickListener(v->send());
        row.addView(top,new LinearLayout.LayoutParams(0,-2,1)); row.addView(send,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);
        root.addView(tv("Transactions",20));
        ScrollView sv=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void topUp(){
        final EditText input=new EditText(this); input.setHint("Enter any amount (₦)"); input.setInputType(2|8192);
        new AlertDialog.Builder(this).setTitle("Top Up Wallet").setView(input).setPositiveButton("TOP UP",(d,w)->{
            try { double x=Double.parseDouble(input.getText().toString()); if(x>0){amount+=x; update("Top Up",x);}}
            catch(Exception e){}
        }).setNegativeButton("CANCEL",null).show();
    }
    void send(){
        final LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText who=new EditText(this); who.setHint("Recipient name"); EditText in=new EditText(this); in.setHint("Amount (₦)"); in.setInputType(2|8192);
        box.addView(who); box.addView(in);
        new AlertDialog.Builder(this).setTitle("Send Money (Demo)").setView(box).setPositiveButton("SEND",(d,w)->{
            try{double x=Double.parseDouble(in.getText().toString()); if(x>0 && x<=amount){amount-=x; update("Sent to "+who.getText(),-x);}}
            catch(Exception e){}
        }).setNegativeButton("CANCEL",null).show();
    }
    void update(String label,double x){
        balance.setText(nf.format(amount).replace("NGN","₦"));
        TextView t=tv((x>=0?"＋ ":"− ")+nf.format(Math.abs(x)).replace("NGN","₦")+"   •   "+label,16);
        list.addView(t,0);
    }
}